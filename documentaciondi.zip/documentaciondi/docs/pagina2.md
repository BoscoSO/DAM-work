# Funcionamiento

## Como utilizarla

Este es un pequeño ejemplo de como se podría utilizar JLabelReloj

<br>

### - Código ejemplo para el formato

~~~
    reloj = new labelPersonalizado.JLabelReloj();

    reloj.setFormato24(true);
~~~

>Con esto tenemos un reloj en formato 24h 


### - Código ejemplo para la alarma

~~~
    reloj = new labelPersonalizado.JLabelReloj();

    reloj.setAlarma(new labelPersonalizado.JLabelRelojAlarma(true,"18:30:00"));
~~~

> De esta manera tenemos una alarma activa puesta para las 18:30


