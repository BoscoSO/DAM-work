module.exports = {
 title: "Documentacion JLabelReloj",
 description: "Documentación del componente personalizado",
 dest: "public",
 base: "/documentacionreloj/",
 themeConfig: {  
    nav: [
        { text: 'Home', link: '/' },
        { text: 'Clases', link: '/pagina1' },
        { text: 'API de JLabel', link: 'https://docs.oracle.com/en/java/javase/11/docs/api/java.desktop/javax/swing/JLabel.html' }
    ],
    sidebar: [
        '/',
        ['/pagina1','Clases'],
        ['/pagina2', 'Funcionamiento']
    ],
    lastUpdated: 'Last Updated', // string | boolean
 } 
}