# JlabelReloj

## Que es?

**JLabelReloj** es un componente personalizado que usa de padre la clase [JLabel][apiJLabel] para mostrar una etiqueta con un reloj
<br><br>![JLabelReloj](./imgs/capturaJLabelReloj.png) 
<br>**-- JLabelReloj** 


## De que sirve


A parte de las funcionalidades inherentes a **JLabel** con **JLabelReloj** puedes mostrar la hora en formato de 12h o 24h. 

**JLabelReloj** tambien te permite establecer una *alarma*, que avisara cuando sea la hora
<br><br>
![JLabelAlarma llego a su hora](./imgs/Alarma_TimesUp.png) 
<br>
## Facil de usar

Si, la complejidad de esta clase no es tan exagerada, puesto que queda todo reducido a dos funciones sencillas e intuitivas para implementar sus funcionalidades 
<br><br>
Sus multiples interfaces hacen de este componente un elemento facil de usar
<br><br>

>Interfaz para inicializar el formato de hora:<br>
>>![JLabelRelojPanel](./imgs/Formato_Panel.png) 

<br>

>Interfaz para inicializar la alarma:<br>
>>![JLabelAlarmaPanel ](./imgs/AlarmaPanel.png) 

<br>


[apiJLabel]:https://docs.oracle.com/en/java/javase/11/docs/api/java.desktop/javax/swing/JLabel.html
















