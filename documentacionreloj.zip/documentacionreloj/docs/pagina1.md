# Clases


##  JLabelReloj

Clase principal, a partir de la cual podemos aplicar distintas funcionalidades.
<br>
- setFormato(boolean b) <br> permite establecer tanto si el reloj esta en formato 12h o 24h (por defecto 12h). 
<br>- Params: boolean b (true para formato 24h)

- setAlarma(Alarma a) <br> añade una alarma al reloj indicando la hora a la que desea que avise, y si la quieres activa o no. 
<br>- Params: Alarma a (Objeto Alarma que recibe un boolean activada y un String hora con formato (hh:mm:ss))

<br>

##  JLabelRelojPropertyEdittorSupport
Esta clase hace de puente entre el BeanInfo de **JLabelReloj** y su panel para gestionar el formato de hora

<br>

## JLabelRelojPanel

Esta clase se encarga de facilitar una interfaz para el entorno de NetBeans para la inicializacion del formato de hora<br>
![JLabelRelojPanel](./imgs/Formato_Panel.png) 

<br>

##  JLabelRelojAlarma
La clase **JLabelRelojAlarma** almacena en su interior dos variables, la hora, con formato "hh:mm:ss" y un boolean que indica si la alarma esta activada<br><br>
Tanto la hora como el boolean se pueden modificar en cualquier momento

<br>

##  JLabelRelojAlarmaPropertyEdittorSupport
Esta clase hace de puente entre el BeanInfo de **JLabelReloj** y su panel para gestionar la alarma

<br>

##  JLabelRelojAlarmaPanel
Esta clase se encarga de facilitar una interfaz para el entorno de NetBeans para la inicializacion de la alarma<br>
![JLabelRelojPanel](./imgs/AlarmaPanel.png) 

